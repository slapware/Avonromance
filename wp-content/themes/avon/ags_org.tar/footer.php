<div id="footer" class="footer">
<div class="follow-us">
<ul>
<li class="facebook"><a href="http://www.facebook.com/avonromance">Follow us on Facebook</a></li>
<li class="twitter"><a href="http://twitter.com/avonbooks">Follow us on Twitter</a></li>
<li class="rss"><a href="/feed">Subscribe to our RSS</a></li>
<li><a style="padding-left:10px" href="/impulse">Avon Impulse</a></li>
</ul>
</div>
<div class="address">
<p>
Copyright &copy; 2012 HarperCollins Publishers. All rights reserved.<br>
195 Broadway, New York, NY 10007 | Phone: (212) 207-7000
</p>
</div>
<div class="terms-of-use">
<ul>
<li><a href="http://harpercollins.com/footer/termsOfUse.aspx" target="_blank">Terms of Use</a></li>
<li><a href="http://www.harpercollins.com/footer/privacyPolicy.aspx" target="_blank">NEW Privacy Policy</a></li>
<li><a href="/sitemap">Site Map</a></li>
<li><a href="mailto:info@avonromance.com">Contact Us</a></li>
</ul>
</div>
</div>

</body>
</html>