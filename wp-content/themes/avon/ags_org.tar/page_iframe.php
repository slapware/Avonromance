<?php
/* Template name: Iframe */
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */

get_header(); ?>
<div class="floral mega">
<h2>Avon Impulse</h2>
</div>
<iframe src="http://impulse.avonromance.com" width="100%" height="2000" style="overflow-x:hidden" frameborder=0></iframe>
<div class="cf"></div>
<?php get_footer(); ?>